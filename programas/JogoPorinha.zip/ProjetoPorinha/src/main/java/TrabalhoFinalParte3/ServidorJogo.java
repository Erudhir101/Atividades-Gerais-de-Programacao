/*
Alunos: Gabriel Carneiro e Luiz Gustavo
Objetivo: Jogo da Porrinha
 */
package TrabalhoFinalParte3;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServidorJogo {

    public static void main(String[] args) {
        String mensagem;
        int count = 0;
        try {
            ServerSocket servidor = new ServerSocket(12345);

            List<Socket> socketList = new ArrayList<>();
            List<String> nomesJogadores = new ArrayList<>();

            while (true) {
                System.out.println("Servidor TCP pronto.");
                socketList.add(servidor.accept()); // servidor está adicionando novas pessoas

                System.out.println("Conexão com cliente " + socketList.get(socketList.size() - 1).
                        getInetAddress().getHostAddress() + " : " + socketList.get(socketList.size() - 1).getPort());

                enviarMensagemIndividual("Cliente adicionado", socketList.get(socketList.size() - 1));

                mensagem = receberMensagemIndividual(socketList.get(socketList.size() - 1));
                String mensagem1 = mensagem.trim().split("#")[0];

                if (mensagem1.equals("PRONTO")) {
                    nomesJogadores.add(mensagem.substring(mensagem.trim().indexOf("#") + 1));
                    enviarMensagemGlobal(nomesJogadores.get(nomesJogadores.size() - 1) + " ENTROU NO JOGO", socketList);
                    //count++;
                }
                if (socketList.size() == 3) {// só para mostrar
                    enviarMensagemGlobal("COMECAR", socketList);
                    enviarMensagemGlobal(String.valueOf(socketList.size()), socketList);
                    mensagensJogo(socketList, nomesJogadores);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Integer> inicializarVetLances(int tamanho) { // inicia a lista de lances
        List<Integer> lances = new ArrayList<>(tamanho);
        for (int i = 0; i < tamanho; i++) {
            lances.add(-1);
        }
        return lances;
    }

    public static void mensagensJogo(List<Socket> socketList, List<String> nomesJogadores) {
        int t = 0, soma, round = 1;
        String mensagem;
        List<Integer> lances = inicializarVetLances(socketList.size());
        while (true) {

            soma = 0;
            enviarMensagemGlobal("--------------------------------------------\nRODADA: " + round, socketList);

            for (int i = t; i < socketList.size(); i++) {
                enviarMensagemIndividual("VEZ", socketList.get(i));
                mensagem = receberMensagemIndividual(socketList.get(i));
                lances.set(i, Integer.valueOf(mensagem.substring(mensagem.trim().indexOf("#") + 1)));
                enviarMensagemGlobal("ATUALIZARLANCE", socketList);
                enviarMensagemGlobal(String.valueOf(lances.get(i)), socketList);
                soma += Integer.valueOf(mensagem.trim().split("#")[0]);
            }

            for (int i = 0; i < t; i++) {
                enviarMensagemIndividual("VEZ", socketList.get(i));
                mensagem = receberMensagemIndividual(socketList.get(i));
                lances.set(i, Integer.valueOf(mensagem.substring(mensagem.trim().indexOf("#") + 1)));
                enviarMensagemGlobal("ATUALIZARLANCE", socketList);
                enviarMensagemGlobal(String.valueOf(lances.get(i)), socketList);
                soma += Integer.valueOf(mensagem.trim().split("#")[0]);
            }

            int temGanhador = -1;

            for (int i = 0; i < lances.size(); i++) {
                if (soma == lances.get(i)) {
                    temGanhador = i;// pegar o index do ganhador da rodada
                }
            }

            //System.out.println("INDEX GANHADOR: " + temGanhador);
            if (temGanhador != -1) {
                //System.out.println("JOGADOR QUE GANHOU FOI: " + nomesJogadores.get(temGanhador));
                enviarMensagemGlobal("Jogador " + nomesJogadores.get(temGanhador) + " GANHOU A RODADA", socketList);
                if (receberMensagemIndividual(socketList.get(temGanhador)).equals("GANHEI")) {
                    //System.out.println("ENTROU NO FINAL");
                    enviarMensagemGlobal("\n\nJogador " + nomesJogadores.get(temGanhador) + " GANHOU A PARTIDA", socketList);
                    try {
                        socketList.get(temGanhador).close();
                    } catch (IOException ex) {
                        Logger.getLogger(ServidorJogo.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    //System.out.println("TEM GANHADOR: " + temGanhador);
                    socketList.remove(temGanhador);
                    nomesJogadores.remove(temGanhador);
                    lances.remove(temGanhador);
                    System.out.println("QTDLISTA: " + socketList.size());
                    System.out.println("POS(0):" + socketList.get(0).getPort());
                    if (socketList.size() == 1) {// sobrou o último jogador que perdeu
                        enviarMensagemGlobal("TERMINOUPARTIDA", socketList);
                        try {
                            socketList.get(0).close();
                            socketList.remove(0);
                        } catch (IOException ex) {
                            Logger.getLogger(ServidorJogo.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        break;
                    }
                }
            } else {
                enviarMensagemGlobal("NENHUM jogador GANHOU A RODADA", socketList);
            }
            if (t >= socketList.size() - 1) {
                t = 0;
            } else {
                t++;
            }
            round++;
            enviarMensagemGlobal("COMBOADICIONAR", socketList);
            enviarMensagemGlobal(String.valueOf(socketList.size()), socketList);
        }
    }

    public static void enviarMensagemGlobal(String mensagem, List<Socket> socketList) {
        for (Socket sai : socketList) {
            try {
                ObjectOutputStream output = new ObjectOutputStream(sai.getOutputStream());
                output.writeObject(mensagem);
            } catch (IOException ex) {
                Logger.getLogger(ServidorJogo.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("Envio de MENSAGEM: " + mensagem);
        }
    }

    public static void enviarMensagemIndividual(String mensagem, Socket socket) {
        try {
            ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            output.writeObject(mensagem);
        } catch (IOException ex) {
            Logger.getLogger(ServidorJogo.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Envio de MENSAGEM: " + mensagem);
    }

    public static String receberMensagemIndividual(Socket socket) {
        try {
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
            return String.valueOf(input.readObject());
        } catch (IOException ex) {
            Logger.getLogger(ServidorJogo.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ServidorJogo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
