package TrabalhoFinalParte3;

import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class Janela03 extends javax.swing.JFrame {

    public Janela03(Jogador jogador) {
        jog = jogador;
        jog.setTela(this);
        initComponents();
        this.isConectadoChat = true;
        this.jog.enviarMensagemServidor("PRONTO#" + jog.getNomeJogador());

        jog.threadJogo();
        jog.conectarChat();
        jLabelNomeJogador.setFont(new java.awt.Font("Arial", 1, 12));
        jLabelNomeJogador.setText(jog.getNomeJogador());
        this.comboAdicionar(1, 3);
        this.jTextFieldQtdPalitos.setText(String.valueOf(jog.getQtdPalito()));
        atualizarOpcoesJogo(2);
    }

    public JTextField getjTextFieldQtdPalitos() {
        return jTextFieldQtdPalitos;
    }

    public void setjTextFieldQtdPalitos(JTextField jTextFieldQtdPalitos) {
        this.jTextFieldQtdPalitos = jTextFieldQtdPalitos;
    }

    public JComboBox<String> getjComboBoxQtdChute() {
        return jComboBoxQtdChute;
    }

    public void setjComboBoxQtdChute(JComboBox<String> jComboBoxQtdChute) {
        this.jComboBoxQtdChute = jComboBoxQtdChute;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtJogo = new javax.swing.JLabel();
        jScrollPaneJogo = new javax.swing.JScrollPane();
        jTextAreaJogo = new javax.swing.JTextArea();
        jSeparator1 = new javax.swing.JSeparator();
        txtConversa = new javax.swing.JLabel();
        jScrollPaneChat = new javax.swing.JScrollPane();
        jTextAreaChat = new javax.swing.JTextArea();
        edtMensagem = new javax.swing.JTextField();
        txtSpanChat = new javax.swing.JLabel();
        btnEnviarChat = new javax.swing.JButton();
        btnEntrarSairChat = new javax.swing.JButton();
        txtNome = new javax.swing.JLabel();
        jLabelNomeJogador = new javax.swing.JLabel();
        txtQtdPalitos = new javax.swing.JLabel();
        jComboBoxQtdMao = new javax.swing.JComboBox<>();
        jComboBoxQtdChute = new javax.swing.JComboBox<>();
        jLabelQtdMao = new javax.swing.JLabel();
        jLabelQtdChute = new javax.swing.JLabel();
        btnEnviarLance = new javax.swing.JButton();
        jTextFieldQtdPalitos = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("JOGO DA PORRINHA");
        setPreferredSize(new java.awt.Dimension(650, 615));

        txtJogo.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtJogo.setText("CHAT DO JOGO");

        jTextAreaJogo.setEditable(false);
        jTextAreaJogo.setColumns(20);
        jTextAreaJogo.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextAreaJogo.setRows(5);
        jScrollPaneJogo.setViewportView(jTextAreaJogo);

        txtConversa.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtConversa.setText("CHAT DE CONVERSA");

        jTextAreaChat.setEditable(false);
        jTextAreaChat.setColumns(20);
        jTextAreaChat.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextAreaChat.setRows(5);
        jScrollPaneChat.setViewportView(jTextAreaChat);

        edtMensagem.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        edtMensagem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                edtMensagemMouseClicked(evt);
            }
        });
        edtMensagem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtMensagemActionPerformed(evt);
            }
        });
        edtMensagem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                edtMensagemKeyTyped(evt);
            }
        });

        txtSpanChat.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        btnEnviarChat.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnEnviarChat.setText("Enviar");
        btnEnviarChat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarChatActionPerformed(evt);
            }
        });
        btnEnviarChat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnEnviarChatKeyPressed(evt);
            }
        });

        btnEntrarSairChat.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnEntrarSairChat.setText("Sair do Chat");
        btnEntrarSairChat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntrarSairChatActionPerformed(evt);
            }
        });

        txtNome.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtNome.setText("JOGADOR:");

        jLabelNomeJogador.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabelNomeJogador.setToolTipText("");

        txtQtdPalitos.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtQtdPalitos.setText("SUA QUANTIDADE DE PALITOS:");

        jComboBoxQtdMao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxQtdMaoActionPerformed(evt);
            }
        });

        jLabelQtdMao.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabelQtdMao.setText("Quantidade da mão");

        jLabelQtdChute.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabelQtdChute.setText("Quantidade total de palpites desta rodada");

        btnEnviarLance.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnEnviarLance.setText("Enviar Lance");
        btnEnviarLance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarLanceActionPerformed(evt);
            }
        });

        jTextFieldQtdPalitos.setEditable(false);
        jTextFieldQtdPalitos.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextFieldQtdPalitos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldQtdPalitosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPaneJogo, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(txtNome)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabelNomeJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(txtQtdPalitos)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextFieldQtdPalitos, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jComboBoxQtdMao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBoxQtdChute, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabelQtdChute)
                                            .addComponent(jLabelQtdMao))))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnEnviarLance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtJogo)
                            .addComponent(txtConversa)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jScrollPaneChat, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 612, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(btnEntrarSairChat)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtSpanChat)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(edtMensagem)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(btnEnviarChat, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                        .addGap(10, 10, 10))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(txtJogo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPaneJogo, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtNome, javax.swing.GroupLayout.DEFAULT_SIZE, 21, Short.MAX_VALUE)
                            .addComponent(jLabelNomeJogador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtQtdPalitos)
                            .addComponent(jTextFieldQtdPalitos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBoxQtdMao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelQtdMao))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelQtdChute)
                            .addComponent(jComboBoxQtdChute, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addComponent(btnEnviarLance, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)))
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtConversa)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPaneChat, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(txtSpanChat)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(edtMensagem, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEntrarSairChat, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEnviarChat, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnEntrarSairChatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntrarSairChatActionPerformed
        if (this.isConectadoChat) { // o botao desabilita/habilita o chat e de enviar a mensagem
            this.jog.desconectar();
            this.btnEntrarSairChat.setText("Entrar Chat");
            this.isConectadoChat = false;
        } else {
            this.isConectadoChat = this.jog.conectarChat();
            if (!this.isConectadoChat) {
                this.adicionarMensagemChat("Erro de conexão");
            } else {
                this.btnEntrarSairChat.setText("Sair Chat");
            }
        }
        this.edtMensagem.setEnabled(this.isConectadoChat);
        this.btnEnviarChat.setEnabled(this.isConectadoChat);
    }//GEN-LAST:event_btnEntrarSairChatActionPerformed

    private void edtMensagemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtMensagemActionPerformed

    }//GEN-LAST:event_edtMensagemActionPerformed

    private void btnEnviarChatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarChatActionPerformed
        if (this.edtMensagem.getText().trim().isEmpty()) {
            this.edtMensagem.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 0)));
            this.txtSpanChat.setForeground(Color.red);
            this.txtSpanChat.setText("NÃO PODE ENVIAR VAZIO... ESCREVA ALGO");
        } else {
            this.jog.enviarMensagemChat(this.edtMensagem.getText(), 1);
            this.edtMensagem.setText("");

        }
        this.edtMensagem.requestFocus();
    }//GEN-LAST:event_btnEnviarChatActionPerformed

    private void jComboBoxQtdMaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxQtdMaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxQtdMaoActionPerformed

    private void btnEnviarLanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarLanceActionPerformed
        if (!String.valueOf(this.jComboBoxQtdMao.getSelectedItem()).equals("QTD")) {
            if (!String.valueOf(this.jComboBoxQtdChute.getSelectedItem()).equals("QTD")) {
                jog.enviarMensagemServidor(String.valueOf(this.jComboBoxQtdMao.getSelectedItem()) + "#" + String.valueOf(this.jComboBoxQtdChute.getSelectedItem()));
                atualizarOpcoesJogo(2);
            }
        }
    }//GEN-LAST:event_btnEnviarLanceActionPerformed

    private void jTextFieldQtdPalitosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldQtdPalitosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldQtdPalitosActionPerformed

    private void edtMensagemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_edtMensagemMouseClicked
        edtMensagem.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51)));
        this.edtMensagem.setText("");
        this.txtSpanChat.setText("");

    }//GEN-LAST:event_edtMensagemMouseClicked

    private void edtMensagemKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_edtMensagemKeyTyped
        if (edtMensagem.getText().trim().isEmpty()) {
            edtMensagem.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51)));
            this.edtMensagem.setText("");
            this.txtSpanChat.setText("");
        }
    }//GEN-LAST:event_edtMensagemKeyTyped

    private void btnEnviarChatKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnEnviarChatKeyPressed
    }//GEN-LAST:event_btnEnviarChatKeyPressed

    public void adicionarMensagemJogo(String mensagem) { // adiciona mensagens no jogo
        this.jTextAreaJogo.append(mensagem + "\n");
    }

    public void adicionarMensagemChat(String mensagem) { // adiciona mensagens no chat
        this.jTextAreaChat.append(mensagem + "\n");
    }

    public void atualizarOpcoesJogo(int i) {
        switch (i) { // desabilitar e habilitar funcoes do jogo
            case 1:
                this.edtMensagem.setEnabled(false);
                this.btnEnviarChat.setEnabled(false);
                this.btnEnviarLance.setEnabled(true);
                this.jComboBoxQtdChute.setSelectedIndex(0);
                this.jComboBoxQtdMao.setSelectedIndex(0);
                this.jComboBoxQtdChute.setEnabled(true);
                this.jComboBoxQtdMao.setEnabled(true);
                break;
            case 2:
                this.edtMensagem.setEnabled(true);
                this.btnEnviarChat.setEnabled(true);
                this.btnEnviarLance.setEnabled(false);
                this.jComboBoxQtdChute.setSelectedIndex(0);
                this.jComboBoxQtdMao.setSelectedIndex(0);
                this.jComboBoxQtdChute.setEnabled(false);
                this.jComboBoxQtdMao.setEnabled(false);
                break;
        }
    }

    public void comboAdicionar(int comeco, int qtdParticipantes) {
        this.jComboBoxQtdMao.removeAllItems();
        this.jComboBoxQtdChute.removeAllItems();
        this.jComboBoxQtdMao.addItem("QTD");
        this.jComboBoxQtdChute.addItem("QTD");
        for (int i = comeco; i <= this.jog.getQtdPalito(); i++) {
            this.jComboBoxQtdMao.addItem(String.valueOf(i));
        }
        for (int i = 0; i <= (qtdParticipantes * 3); i++) {
            this.jComboBoxQtdChute.addItem(String.valueOf(i));
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Janela03.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Janela03.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Janela03.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Janela03.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Janela03().setVisible(true);
//            }
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEntrarSairChat;
    private javax.swing.JButton btnEnviarChat;
    private javax.swing.JButton btnEnviarLance;
    private javax.swing.JTextField edtMensagem;
    private javax.swing.JComboBox<String> jComboBoxQtdChute;
    private javax.swing.JComboBox<String> jComboBoxQtdMao;
    private javax.swing.JLabel jLabelNomeJogador;
    private javax.swing.JLabel jLabelQtdChute;
    private javax.swing.JLabel jLabelQtdMao;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPaneChat;
    private javax.swing.JScrollPane jScrollPaneJogo;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextArea jTextAreaChat;
    private javax.swing.JTextArea jTextAreaJogo;
    private javax.swing.JTextField jTextFieldQtdPalitos;
    private javax.swing.JLabel txtConversa;
    private javax.swing.JLabel txtJogo;
    private javax.swing.JLabel txtNome;
    private javax.swing.JLabel txtQtdPalitos;
    private javax.swing.JLabel txtSpanChat;
    // End of variables declaration//GEN-END:variables
    private boolean isConectadoChat;
    private Jogador jog;
}
