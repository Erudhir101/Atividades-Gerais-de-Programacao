package TrabalhoFinalParte3;

import java.net.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Jogador {

    private MulticastSocket multSocket;
    private Socket socket;
    private InetAddress group;
    private ObjectOutputStream dgSaida;
    private ObjectInputStream dgEntrada;
    private DatagramPacket dgSaidaChat;
    private DatagramPacket dgEntradaChat;
    private Janela03 tela;
    private int qtdPalitos;
    private String nomeJogador;
    private String host;
    private int qtdJogadores;

//    byte[] saida = new byte[1000];
//    byte[] entrada = new byte[1000];
    byte[] saidaChat = new byte[1000];
    byte[] entradaChat = new byte[1000];

    public Jogador() {
        this.qtdPalitos = 3;// padrão para o jogo
        //this.host = "230.0.0.0";
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    public Janela03 getTela() {
        return tela;
    }

    public void setTela(Janela03 tela) {
        this.tela = tela;
    }

    public int getQtdPalito() {
        return qtdPalitos;
    }

    public void setQtdPalito(int qtdPalito) {
        this.qtdPalitos = qtdPalito;
    }

    public String getNomeJogador() {
        return nomeJogador;
    }

    public void setNomeJogador(String nomeJogador) {
        this.nomeJogador = nomeJogador;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public ObjectInputStream getDgEntrada() {
        return dgEntrada;
    }

    public void setDgEntrada(ObjectInputStream dgEntrada) {
        this.dgEntrada = dgEntrada;
    }

//    public byte[] getEntrada() {
//        return entrada;
//    }
//
//    public void setEntrada(byte[] entrada) {
//        this.entrada = entrada;
//    }
    public boolean iniciarConexao() {
        try {
            socket = new Socket("localhost", 12345);
            dgEntrada = new ObjectInputStream(socket.getInputStream());
            System.out.println("MENSAGEM: " + dgEntrada.readObject());
            return true;

        } catch (IOException ex) {
            Logger.getLogger(Jogador.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Jogador.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public boolean conectarChat() {
        try {
            multSocket = new MulticastSocket(4446);
            group = InetAddress.getByName(host);
            multSocket.joinGroup(group);
            dgEntradaChat = new DatagramPacket(entradaChat, entradaChat.length, group, 4446);
            dgSaidaChat = new DatagramPacket(saidaChat, saidaChat.length, group, 4446);

            this.threadChat();// inicia uma thread para o chat
            this.enviarMensagemChat(nomeJogador + " ENTROU NO CHAT", 2);

            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Não entrou");
        return false;
    }

    public void desconectar() {
        this.enviarMensagemChat("USUÁRIO " + nomeJogador + " SAIU DO CHAT", 2);
    }

    public void threadJogo() {
        new Thread() {
            public void run() {
                String mensagemJogo;
                while (true) {
                    mensagemJogo = receberMensagemServidor();
                    if (mensagemJogo.equals("COMECAR")) {
                        qtdJogadores = Integer.valueOf(receberMensagemServidor());
                        System.out.println("QTD: " + qtdJogadores);
                        tela.comboAdicionar(1, qtdJogadores);
                        tela.adicionarMensagemJogo("\n\n    -------------------------------------\n"
                                + "      COMEÇOU A PARTIDA!!!\n"
                                + "    -------------------------------------\n");
                        continue;
                    }

                    if (mensagemJogo.equals("TERMINOUPARTIDA")) {
                        tela.adicionarMensagemJogo("TERMINOU A PARTIDA, VOCÊ VAI TER QUE PAGAR A CONTA!!!");
                        break;
                    }

                    if (mensagemJogo.equals("Jogador " + nomeJogador + " GANHOU A RODADA")) {
                        qtdPalitos--;
                        tela.getjTextFieldQtdPalitos().setText(String.valueOf(qtdPalitos));
                        if (qtdPalitos == 0) {
                            enviarMensagemServidor("GANHEI"); //Enviar mensagem para o servidor dizendo que ganhou
                            tela.adicionarMensagemJogo("\nVOCÊ GANHOU A PARTIDA!!!");
                            break;
                        } else {
                            enviarMensagemServidor("OK");
                        }
                    }

                    if (mensagemJogo.equals("COMBOADICIONAR")) {
                        tela.comboAdicionar(0, Integer.valueOf(receberMensagemServidor()));
                        continue;
                    }

                    if (mensagemJogo.equals("VEZ")) {
                        tela.atualizarOpcoesJogo(1);
                        tela.adicionarMensagemJogo("É SUA VEZ");
                        continue;
                    }

                    if (mensagemJogo.equals("ATUALIZARLANCE")) {
                        String item = receberMensagemServidor();
                        tela.getjComboBoxQtdChute().removeItem(item.trim());
                        continue;
                    }
                    tela.adicionarMensagemJogo(mensagemJogo);
                }
            }
        }.start();
    }

    public void enviarMensagemServidor(String msg) {
        String texto = msg;
        try {
            dgSaida = new ObjectOutputStream(socket.getOutputStream());
            dgSaida.writeObject(texto);// trocar texto por mensagem
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String receberMensagemServidor() {
        String texto = "";
        try {
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
            texto = String.valueOf(input.readObject());
        } catch (IOException ex) {
            Logger.getLogger(Jogador.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Jogador.class.getName()).log(Level.SEVERE, null, ex);
        }
        return texto;
    }

    public void threadChat() {
        new Thread() {
            public void run() {
                try {
                    String mensagemChat;
                    do {// fica recebendo as mensagens até sair
                        multSocket.receive(dgEntradaChat);
                        mensagemChat = (new String(entradaChat)).trim().split("#")[0];
                        if (mensagemChat.equals("USUÁRIO " + nomeJogador + " SAIU DO CHAT")) {
                            tela.adicionarMensagemChat("VOCÊ SAIU DO CHAT");
                            multSocket.close();
                            break;
                        }
                        tela.adicionarMensagemChat(mensagemChat);
                    } while (!mensagemChat.equals("USUÁRIO " + nomeJogador + " SAIU DO CHAT"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    public void enviarMensagemChat(String msg, int i) {
        String texto;
        switch (i) {
            case 1:
            default:
                texto = (nomeJogador + ": " + msg + "#");
                break;
            case 2:
                texto = (msg + "#");
                break;
        }
        saidaChat = texto.getBytes();
        try {
            dgSaidaChat.setData(saidaChat);
            dgSaidaChat.setLength(texto.length());
            multSocket.send(dgSaidaChat);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
